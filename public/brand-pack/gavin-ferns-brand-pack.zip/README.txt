Gavin Ferns Consulting brand pack

Logo lockups: 1200 × 360 PNG plus the scalable, transparent CGF mark (SVG)
Instagram profile: 1080 × 1080 PNG, with the mark centred for circular cropping
Instagram square: 1080 × 1080 PNG
Instagram portrait: 1080 × 1350 PNG
Instagram story: 1080 × 1920 PNG
Open Graph: 1200 × 630 JPG for link previews

Use the light variants on light layouts and the dark variants on dark layouts.
Keep the logo proportions and leave space around the mark.

Palette
Navy #07172D
Ink #0C1B32
Blue #1559CC
Sky #8BBAFF
Light tint #F3F7FC
White #FFFFFF

gavinferns.com
